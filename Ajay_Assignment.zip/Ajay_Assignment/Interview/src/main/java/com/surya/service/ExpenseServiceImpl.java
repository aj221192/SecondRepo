package com.surya.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.surya.dao.ExpenseDAO;
import com.surya.model.Expense;

@Service
@Transactional
public class ExpenseServiceImpl implements ExpenseService {

	@Autowired
	private ExpenseDAO expenseDAO;

	@Override
	@Transactional
	public void addExpense(Expense expense) {
		expenseDAO.addExpense(expense);
	}

	@Override
	@Transactional
	public List<Expense> getAllExpense() {
		return expenseDAO.getAllExpense();
	}

	@Override
	@Transactional
	public void deleteExpense(Integer expenseId) {
		expenseDAO.deleteExpense(expenseId);
	}

	public Expense getExpense(int expid) {
		return expenseDAO.getExpense(expid);
	}

	
	public void setExpenseDAO(ExpenseDAO expenseDAO) {
		this.expenseDAO = expenseDAO;
	}

}
