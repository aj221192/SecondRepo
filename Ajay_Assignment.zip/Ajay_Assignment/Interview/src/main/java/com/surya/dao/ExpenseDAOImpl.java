package com.surya.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.surya.model.Expense;

@Repository
public class ExpenseDAOImpl implements ExpenseDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public void addExpense(Expense expense) {
		sessionFactory.getCurrentSession().saveOrUpdate(expense);

	}

	@SuppressWarnings("unchecked")
	public List<Expense> getAllExpense() {

		return sessionFactory.getCurrentSession().createQuery("from Expense")
				.list();
	}

	@Override
	public void deleteExpense(Integer expenseId) {
		Expense expense = (Expense) sessionFactory.getCurrentSession().load(
				Expense.class, expenseId);
		if (null != expense) {
			this.sessionFactory.getCurrentSession().delete(expense);
		}

	}

	public Expense getExpense(int expid) {
		return (Expense) sessionFactory.getCurrentSession().get(
				Expense.class, expid);
	}



}