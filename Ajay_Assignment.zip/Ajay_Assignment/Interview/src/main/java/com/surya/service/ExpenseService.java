package com.surya.service;

import java.util.List;


import com.surya.model.Expense;

public interface ExpenseService {
	
	public void addExpense(Expense expense);

	public List<Expense> getAllExpense();

	public void deleteExpense(Integer expenseId);

	public Expense getExpense(int expenseid);

}
