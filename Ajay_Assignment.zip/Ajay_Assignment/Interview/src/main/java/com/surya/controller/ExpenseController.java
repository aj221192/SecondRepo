package com.surya.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.surya.model.Expense;
import com.surya.service.ExpenseService;

@Controller
public class ExpenseController {

	private static final Logger logger = Logger
			.getLogger(ExpenseController.class);

	public ExpenseController() {
		System.out.println("ExpenseController()");
	}

	@Autowired
	private ExpenseService expenseService;

	@RequestMapping(value = "/")
	public ModelAndView listclient(ModelAndView model) throws IOException {
		List<Expense> listclient = expenseService.getAllExpense();
		model.addObject("listclient", listclient);
		model.setViewName("index");
		return model;
	}

	


	@RequestMapping(value = "/newExpense", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		Expense expense = new Expense();
		model.addObject("expense", expense);
		model.setViewName("Add_Exp");
		return model;
	}

	@RequestMapping(value = "/saveExpense", method = RequestMethod.POST)
	public ModelAndView saveExpense(@ModelAttribute Expense expense) {
		if (expense.getId() == 0) { // if employee id is 0 then creating the
			// employee other updating the employee
			expenseService.addExpense(expense);
		} 
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/deleteExpense", method = RequestMethod.GET)
	public ModelAndView deleteExpense(HttpServletRequest request) {
		int expenseId = Integer.parseInt(request.getParameter("id"));
		expenseService.deleteExpense(expenseId);
		return new ModelAndView("redirect:/"); 
	}

	@RequestMapping(value = "/listExpense", method = RequestMethod.GET)
	public ModelAndView editContact(HttpServletRequest request) {
		int expenseId = Integer.parseInt(request.getParameter("id"));
		Expense expense = expenseService.getExpense(expenseId);
		ModelAndView model = new ModelAndView("viewexp");
		model.addObject("expense", expense);

		return model;
	}

}